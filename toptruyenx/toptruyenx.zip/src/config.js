let BASE_URL = 'https://www.toptruyenzone3.com';
let BASE_URL1 = 'https://doctruyen3qx.pro'
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}