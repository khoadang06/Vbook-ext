function execute() {
    return Response.success([
        { title: "玄幻", input: "/xclass/xuanhuan/", script: "cate.js" },
        { title: "武侠", input: "/xclass/wuxia/", script: "cate.js" },
        { title: "现代", input: "/xclass/dushi/", script: "cate.js" },
        { title: "历史", input: "/xclass/lishi/", script: "cate.js" },
        { title: "惊悚", input: "/xclass/jingsong/", script: "cate.js" },
        { title: "科幻", input: "/xclass/kehuan/", script: "cate.js" },
        { title: "恐怖", input: "/xclass/zilao/", script: "cate.js" },
        { title: "耽美", input: "/xclass/baihe/", script: "cate.js" },
        { title: "管理哲学", input: "/xclass/zhexue/", script: "cate.js" },
        { title: "网游竞技", input: "/xclass/wangyou/", script: "cate.js" },
        { title: "美文同人", input: "/xclass/tongren/", script: "cate.js" },
        { title: "言情", input: "/xclass/yangqing/", script: "cate.js" },
        { title: "穿越", input: "/xclass/chuanyue/", script: "cate.js" },
    ]);
}
