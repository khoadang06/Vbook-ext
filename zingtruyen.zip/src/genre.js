function execute() {
    return Response.success([
        { title: "Truyện teen", input: "https://zingtruyen.site/category/truyen-teen", script: "gen.js" },
        { title: "Fanfiction", input: "https://zingtruyen.site/category/truyen-fanfiction", script: "gen.js" },
        { title: "Tiểu thuyết", input: "https://zingtruyen.site/category/tieu-thuyet", script: "gen.js" },
        { title: "Lãng mạn", input: "https://zingtruyen.site/category/truyen-lang-man", script: "gen.js" },
        { title: "Huyền ảo", input: "https://zingtruyen.site/category/truyen-huyen-ao", script: "gen.js" },
        { title: "Phi tiểu thuyết", input: "https://zingtruyen.site/category/truyen-phi-tieu-thuyet", script: "gen.js" },
        { title: "Hài hước", input: "https://zingtruyen.site/category/truyen-hai-huoc", script: "gen.js" },
        { title: "Siêu nhiên", input: "https://zingtruyen.site/category/truyen-sieu-nhien", script: "gen.js" },
        { title: "Bí ẩn", input: "https://zingtruyen.site/category/truyen-bi-an", script: "gen.js" },
        { title: "Kinh dị", input: "https://zingtruyen.site/category/truyen-kinh-di", script: "gen.js" },
        { title: "Phiêu lưu", input: "https://zingtruyen.site/category/truyen-phieu-luu", script: "gen.js" },
        { title: "Cổ đại", input: "https://zingtruyen.site/category/truyen-co-dai", script: "gen.js" },
        { title: "Thơ ca", input: "https://zingtruyen.site/category/tho-ca", script: "gen.js" },
        { title: "Truyện ngắn", input: "https://zingtruyen.site/category/truyen-ngan", script: "gen.js" },
        { title: "Hành động", input: "https://zingtruyen.site/category/truyen-hanh-dong", script: "gen.js" },
        { title: "Ma cà rồng", input: "https://zingtruyen.site/category/truyen-ma-ca-rong", script: "gen.js" },
        { title: "Người sói", input: "https://zingtruyen.site/category/truyen-nguoi-soi", script: "gen.js" },
        { title: "Tâm linh", input: "https://zingtruyen.site/category/truyen-tam-linh", script: "gen.js" },
        { title: "Khoa học - viễn tưởng", input: "https://zingtruyen.site/category/truyen-khoa-hoc-vien-tuong", script: "gen.js" },
        { title: "Ngẫu nhiên", input: "https://zingtruyen.site/category/truyen-ngau-nhien", script: "gen.js" }
    ]);
}