function execute(url) {
    let response = fetch(url, {
        headers: {
            'token': 'eyJhbGciOiJIUzI1NiJ9.eyJpZCI6ODYwNzIxNzA0MDMxMzU4OTc2LCJ0eXBlIjoiY3VzdG9tZXIiLCJ0aW1lc3RhbXAiOjE2ODUzNzg1MTE1NzQsImV4cCI6MTY4NTk4MzMxMX0.-FX7rOJP7I10ApjeM5NVaGj57aeYnkVyopniC7U_Dv8'
        }
    });
    if (response.ok) {
        let doc = response.json();
        let content = doc.model.lines.join("<br>");
        return Response.success(content);
    }
    return null;
}