function execute(url) {
    let response = fetch(url);
    if (response.ok) {
        let doc = response.json();
        let content = doc.model.lines.join("<br>");
        return Response.success(content);
    }
    return null;
}