load('config.js');

function execute(url) {
    url = url.replace("/intro?id=", "/catalog/")
    let response = fetch(url);
    if (response.ok) {
        let json = response.json();
        let ele = json.model.children||json.model.menus
        let chapters = [];
        ele.forEach(e => {
            chapters.push({
                name: e.title.replace("••","").replace(/^(\d+).第/,'第').replace(/^(正文|VIP章节|最新章节)?(\s+|_)|[\(\{（｛【].*[求更谢乐发推票盟补加字Kk\/].*[\)\}）｝】]/g,'').replace(/^(\d+)[、．]第.+章/,'第$1章').replace(/^(\d+)、\d+、/,'第$1章 ').replace(/^(\d+)、\d+/,'第$1章').replace(/^(\d+)、/,'第$1章 ').replace(/^(第.+章)\s?第.+章/,'$1').replace(/\(.+\)/,'').replace(/\[|。/,''),
                 url: "https://api.uaa.com/novel/app/novel/chapter?id=" + e.id + "&offset=0&viewId=" + e.volumeNum,
                host: BASE_URL
            })
        });

        return Response.success(chapters);
    }

    return null;
}