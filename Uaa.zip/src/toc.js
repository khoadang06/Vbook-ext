load('config.js');

function execute(url) {
    url = url.replace("/intro?id=", "/catalog/")
    let response = fetch(url, {
        headers: {
            "token": "eyJhbGciOiJIUzI1NiJ9.eyJpZCI6ODYwNzIxNzA0MDMxMzU4OTc2LCJ0eXBlIjoiY3VzdG9tZXIiLCJ0aW1lc3RhbXAiOjE2ODUzNzg1MTE1NzQsImV4cCI6MTY4NTk4MzMxMX0.-FX7rOJP7I10ApjeM5NVaGj57aeYnkVyopniC7U_Dv8"
        }
    });
    if (response.ok) {
        let json = response.json();
        let chapters = [];
        let volumes = [];

        if (json.model) {
            let ele = json.model.children || json.model.menus;

            // Sử dụng đoạn mã .[?(@.title)] để lọc các phần tử có tiêu đề
            ele.forEach(e => {
                if (e.title) {  // Kiểm tra nếu phần tử có title
                    if (e.children && e.children.length > 0) {
                        volumes.push({
                            name: cleanTitle(e.title),
                            chapters: extractChapters(e)
                        });
                    } else {
                        chapters.push({
                            name: cleanTitle(e.content) || e.title,
                            url: "https://www.uaa.com/novel/chapter?id=" + e.id,
                            host: BASE_URL
                        });
                    }
                }
            });
        }
        return Response.success(chapters.concat(volumes));
    }
    return null;
}

function cleanTitle(title) {
    return title.replace("••", "").replace(/^(\d+).第/, '第')
        .replace(/^(正文|VIP章节|最新章节)?(\s+|_)|[\{（｛【].*[求更谢乐发推票盟补加字Kk\/].*[\}）｝】]/g, '')
        .replace(/^(\d+)[、．]第.+章/, '第$1章').replace(/^(\d+)、\d+、/, '第$1章 ')
        .replace(/^(\d+)、\d+/, '第$1章').replace(/^(\d+)、/, '第$1章 ')
        .replace(/^(第.+章)\s?第.+章/, '$1').replace(/.+/, '').replace(/\[|。/, '');
}

function extractChapters(data) {
    const chapters = [];
    if (data.children) {
        data.children.forEach(chapter => {
            if (chapter.title) {  // Lọc các phần tử có title
                chapters.push({
                    name: cleanTitle(chapter.content) || chapter.title,
                    url: "https://www.uaa.com/novel/chapter?id=" + chapter.id,
                    host: BASE_URL
                });
            }
        });
    }
    return chapters;
}