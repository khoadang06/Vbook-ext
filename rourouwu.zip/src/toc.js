load('config.js');
function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    let  url1 = url.replace("/novel/","/novel/list/").replace(".html","/1.html");
    let response = fetch(url1);
    if (response.ok) {
        let doc = response.html();
        let el = doc.select("ul").first().select("li a")
        const data = [];
        for (let i = 0; i < el.size(); i++) {
            var e = el.get(i);
            data.push({
                name: e.select("a").text(),
                url: BASE_URL + e.attr("href"),
                host: BASE_URL
            })
        }
        return Response.success(data.reverse());
    }
    return null;
}