function execute() {
    return Response.success([
        { title: "玄幻", input: "/xuanhuan/", script: "updates.js" },
        { title: "武侠", input: "/wuxia/", script: "updates.js" },
        { title: "都市", input: "/dushi/", script: "updates.js" },
        { title: "历史", input: "/lishi/", script: "updates.js" },
        { title: "游戏", input: "/youxi/", script: "updates.js" },
        { title: "科幻", input: "/kehuan/", script: "updates.js" },
        { title: "恐怖", input: "/xuanyi/", script: "updates.js" },
        { title: "其他", input: "/qita/", script: "updates.js" },
        { title: "古代", input: "/guyan/", script: "updates.js" },
        { title: "现代", input: "/xianyan/", script: "updates.js" },
        { title: "幻想", input: "/huanqing/", script: "updates.js" },
        { title: "游戏", input: "/zongcai/", script: "updates.js" },
        { title: "浪漫", input: "/qingchun/", script: "updates.js" },
        { title: "言情", input: "/wangluo/", script: "updates.js" },
        { title: "科幻", input: "/mmkehuan/", script: "updates.js" },
        { title: "其他", input: "/mmqita/", script: "updates.js" },
    ]);
}
