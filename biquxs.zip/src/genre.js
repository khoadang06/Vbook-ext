function execute() {
    return Response.success([
        { title: "玄幻", input: "/class/1/", script: "cate.js" },
        { title: "武侠", input: "/class/2/", script: "cate.js" },
        { title: "都市", input: "/class/3/", script: "cate.js" },
        { title: "历史", input: "/class/4/", script: "cate.js" },
        { title: "游戏", input: "/class/5/", script: "cate.js" },
        { title: "科幻", input: "/class/6/", script: "cate.js" },
        { title: "恐怖", input: "/class/7/", script: "cate.js" },
        { title: "其他", input: "/class/8/", script: "cate.js" },
        { title: "全本小说", input: "/over/", script: "cate.js" },
    ]);
}
