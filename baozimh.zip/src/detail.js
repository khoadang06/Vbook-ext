load('config.js')
function execute(url) {
    const doc = fetch(url).html()
    return Response.success({
        name: doc.select("h1").last().text().replace(/NEW |Ongoing /gi,''),
        cover: doc.select("amp-img").attr("src"),
        author: doc.select("h2").last().text(),
        description: doc.select(".comics-detail__desc").text(),
        detail: doc.select("div.supporting-text > div:nth-child(1)").html()+ "<br>" + doc.select("div.supporting-text > div:nth-child(2)").html(),
        category: doc.select(".tag").html(),
        host: BASE_URL
    });
}