load('config.js');
function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    const doc = fetch(BASE_URL + url).html();
    const el = doc.select(".pure-g > div")
    const data = [];
    for (var i = 0; i < el.size(); i++) {
        var e = el.get(i);
        data.push({
            name: e.select("h3").last().text(),
            link: e.select("a").first().attr("href"),
            cover: e.select("amp-img").attr("src"),
            description: e.select(".text-truncate small").first().text(),
            host: BASE_URL
        })
    }
    return Response.success(data)
}