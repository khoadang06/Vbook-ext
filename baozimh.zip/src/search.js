load("config.js");
function execute(key) {
    let response = fetch(BASE_URL + "/search?q=" + key);
    if (response.ok) {
        let doc = response.html();
        let books = [];
        doc.select(".pure-g > div").forEach(e => {
            let img = e.select("amp-img").attr("src");
            books.push({
              name: e.select(".comics-card__title").first().text(),
              link: BASE_URL + e.select("a").first().attr("href"),
              cover: img,
              description: e.select(".comics-card__title").text(),
                host: BASE_URL
            })
        });
        return Response.success(books);
    }

    return null;
}