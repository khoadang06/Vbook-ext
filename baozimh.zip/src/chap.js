function execute(url) {
    var doc = fetch(url).html();
    var el = doc.select(".comic-contain div amp-img");   
    var data = [];
    for (var i = 0; i < el.size(); i++) {
        var e = el.get(i);
        data.push(e.attr("data-src"));     
    }
    return Response.success(data);
}