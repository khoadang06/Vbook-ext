function execute() {
    return Response.success([
        { title: "都市激情", input: "/category/15", script: "cate.js" },
        { title: "家庭亂倫", input: "/category/6", script: "cate.js" },
        { title: "人妻交換", input: "/category/18", script: "cate.js" },
        { title: "另類小說", input: "/category/17", script: "cate.js" },
        { title: "校園春色", input: "/category/16", script: "cate.js" },
        { title: "亂倫文學", input: "/category/23", script: "cate.js" },
        { title: "學生校園", input: "/category/4", script: "cate.js" },
        { title: "人妻熟女", input: "/category/11", script: "cate.js" },
        { title: "都市生活", input: "/category/5", script: "cate.js" },
        { title: "人妻文學", input: "/category/25", script: "cate.js" },
        { title: "另類文學", input: "/category/21", script: "cate.js" },
        { title: "強暴虐待", input: "/category/7", script: "cate.js" },
        { title: "動漫改編", input: "/category/13", script: "cate.js" },
        { title: "武俠科幻", input: "/category/9", script: "cate.js" },
        { title: "名人明星", input: "/category/12", script: "cate.js" },
    ]);
}