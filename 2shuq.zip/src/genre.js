function execute() {
    return Response.success([
        { title: "玄幻魔法", input: "/class/1/_", script: "cate.js" },
        { title: "武侠修真", input: "/class/2/_", script: "cate.js" },
        { title: "都市言情", input: "/class/3/_", script: "cate.js" },
        { title: "历史军事", input: "/class/4/_", script: "cate.js" },
        { title: "科幻灵异", input: "/class/7/_", script: "cate.js" },
        { title: "游戏竞技", input: "/class/6/_", script: "cate.js" },
        { title: "女生耽美", input: "/class/8/_", script: "cate.js" },
        { title: "精品推荐", input: "/class/10/_", script: "cate.js" },
    ]);
}