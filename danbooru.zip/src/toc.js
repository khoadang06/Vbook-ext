load('config.js');
function execute(url) {
    const data = [];
    data.push({
        name: "0",
        url: url,
        host: BASE_URL
    })
    return Response.success(data);
}