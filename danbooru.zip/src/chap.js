function execute(url) {
    var doc = fetch(url).html();
    var el = doc.select("#content .image-container picture img");

    var data = [];

    el.forEach(e => {
        data.push(e.attr("src"));
    });

    return Response.success(data);
}
