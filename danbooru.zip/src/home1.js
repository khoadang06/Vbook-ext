load('config.js');
function execute(url,page) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (!page) page = '1';
    const doc = fetch(BASE_URL + url + "?page=" + page).html();
    const el = doc.select(".post-preview")
    const data = [];
    for (var i = 0; i < el.size(); i++) {
        var e = el.get(i);
        let img = e.select(".post-preview-container a picture img").first().attr("src");
        data.push({
            name: e.select(".post-preview-container a picture img").first().attr("title"),
            link: BASE_URL + e.select("a").first().attr("href"),
            cover: img,
            description: e.select(".post-preview-container a picture img").first().attr("title"),
            host: BASE_URL
        })
    }
    let next = (parseInt(page) + 1).toString();
    return Response.success(data,next)
}