function execute() {
    return Response.success([
        {title: "Cập nhật", input: "/", script: "up.js"},
    ]);
}