function execute(url) {
    let baseUrl = url.match(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img)[0];
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        let chapters = [];
        
        let firstChapterUrl = doc.select("#chapter-list div ul li a").first().attr("href");
        let firstChapterName = null;
        
        let nextChapterUrl = firstChapterUrl;
        while (nextChapterUrl) {
            let nextResponse = fetch(baseUrl + nextChapterUrl);
            if (nextResponse.ok) {
                let nextDoc = nextResponse.html();
                
                let currentChapterName = nextDoc.select(".current-chapter").text();
                
                if (!firstChapterName) {
                    firstChapterName = currentChapterName;
                }
                
                let chapterLink = baseUrl + nextChapterUrl;
                if (chapterLink !== baseUrl + "#") {
                    chapters.push({
                        name: currentChapterName,
                        url: chapterLink,
                        host: baseUrl
                    });
                }
                
                nextChapterUrl = nextDoc.select(".next").attr("href");
                
                firstChapterName = currentChapterName;
            } else {
                break;
            }
        }

        return Response.success(chapters);
    }

    return null;
}