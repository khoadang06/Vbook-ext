function execute() {
    return Response.success([
        { title: "玄幻魔法", input: "/leibie1_", script: "gen.js" },
        { title: "武侠修真", input: "/leibie2_", script: "gen.js" },
        { title: "都市言情", input: "/leibie3_", script: "gen.js" },
        { title: "历史军事", input: "/leibie4_", script: "gen.js" },
        { title: "侦探推理", input: "/leibie5_", script: "gen.js" },
        { title: "网游动漫", input: "/leibie6_", script: "gen.js" },
        { title: "科幻小说", input: "/leibie7_", script: "gen.js" },
        { title: "恐怖灵异", input: "/leibie8_", script: "gen.js" },
        { title: "散文诗词", input: "/leibie9_", script: "gen.js" },
        { title: "其他类型", input: "/leibie10_", script: "gen.js" },
    ]);
}