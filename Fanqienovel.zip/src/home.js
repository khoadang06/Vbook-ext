function execute() {
    return Response.success([
        {
            title: "༺ 无敌 ༻ [推荐] 全部",
            input: "https://tsearch.toutiaoapi.com/2/wap/search/extra/novel_operator?tab_name=%25E5%2585%25A8%25E9%2583%25A8%25E5%2588%2586%25E7%25B1%25BB&ala_src=novel_tag&gender=0&is_finish=0&iid=2008145514494631&aid=13&app_name=news_article&version_code=692&version_name=6.9.2&abflag=3&partner=novel_tag&offset=",
            script: "homecontent.js"
        }
    ]);
}