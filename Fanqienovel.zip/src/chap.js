function execute(url) {
    let response = fetch(url);
    let html = response.text();
    let chapterContent = "";
        let jsonResponse = JSON.parse(html);
        let res = jsonResponse.data.content;
        let result = String(res);

        function getComic(result) {
            let mat = result.match(/<article>([\s\S]*?)<\/article>/);
            try {
                let cnt = JSON.parse(
                    mat
                        ? mat[1].replace(/\&/g, '"').replace(/\;/g, "").replace(/#34/g, '"')
                        : result
                );
                return (mat ? cnt.skeleton.data : cnt.picInfos)
                    .map((i) => {
                        let path = mat
                            ? cnt.materials[i.element_name].data.web_uri
                            : "novel-pic/" + i.md5;
                        return `<img src="https://p3-novel.byteimg.com/origin/${path}">`;
                    })
                    .join("<br>");
            } catch (e) {
                mat = result.match(/<body>([\s\S]*?)<\/body>/)
                return (mat ? mat[1] : result).toString().replace(/<\!DOCTYPE html.*/g, "").replace(/<tt_keyword_ad.*<\/tt_keyword_ad>/, "").replace(/<a epub.*>\\<\/a>/g, "")
            }
        }
        chapterContent = getComic(result).replace(/\{\!\-\- PGC_VOICE\:.*?\-\-\}/g, "");
    return Response.success(chapterContent);
}