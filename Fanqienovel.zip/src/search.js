function execute(key, page) {
    let baseUrl = "http://yuefanqie.jingluo.love";
    let searchUrl = baseUrl + `/search?query=${encodeURIComponent(key)}&offset=${(page - 1) * 10}`;

    let response = fetch(searchUrl);
    let resultText = response.text();
    let searchData = JSON.parse(resultText);

    let books;
    if (searchData.search_tabs) {
        searchData.search_tabs.forEach((i) => {
            if (i.tab_type == 3) books = i.data;
        });
    } else {
        books = searchData.data;
    }

    let results = [];
    if (books) {
        books.forEach(w => {
            if (w.book_data && w.book_data[0]) {
                results.push(w.book_data[0]);
            } else if (w.book_data) {
                results.push(w.book_data);
            } else {
                results.push(w);
            }
        });
    }

    const replaceCover = (u) => {
        if (u.startsWith("https://")) u = u.substring(8)
        else u = u.substring(7)
        let uArr = u.split("/")
        uArr[0] = "https://p6-novel.byteimg.com/origin"
        let uArr2 = []
        uArr.forEach((x) => {
            if (!x.includes("?") && !x.includes("~")) uArr2.push(x)
            else uArr2.push(x.split("~")[0])
        })
        u = uArr2.join("/")
        return u
    };


    let searchResults = [];
    results.forEach(book => {
        searchResults.push({
            name: book.book_name,
            link: baseUrl + `/detail?book_id=${book.book_id}`,
            cover: replaceCover(book.thumb_url),
            description: book.abstract
        });
    });

    let nextPage = page ? parseInt(page) + 1 : 2;
    return Response.success(searchResults, String(nextPage));
}