function execute(url) {
    let detailUrl = url;
    const pageIdMatch = url.match(/https:\/\/fanqienovel\.com\/page\/(\d+)/);
    if (pageIdMatch) {
        const bookId = pageIdMatch[1];
        detailUrl = `http://yuefanqie.jingluo.love/detail?book_id=${bookId}`;
    }

    let response = fetch(detailUrl);
    let html = response.text();
    let detailData;
        let jsonResponse = JSON.parse(html);
        let data = jsonResponse.data;

        const replaceCover = (u) => {
            if (u.startsWith("https://")) u = u.substring(8)
            else u = u.substring(7)
            let uArr = u.split("/")
            uArr[0] = "https://p6-novel.byteimg.com/origin"
            let uArr2 = []
            uArr.forEach((x) => {
                if (!x.includes("?") && !x.includes("~")) uArr2.push(x)
                else uArr2.push(x.split("~")[0])
            })
            u = uArr2.join("/")
            return u
        };

        let genres = [];
        if (Array.isArray(data.category_v2)) {
            genres = data.category_v2.map(cat => ({ title: cat.Name }));
        }

        let rolesText = "";
        if (data.roles) {
            try {
                let rolesArray = JSON.parse(data.roles);
                if (Array.isArray(rolesArray)) {
                    rolesText = rolesArray.join(', ');
                } else {
                    rolesText = String(data.roles);
                }
            } catch (e) {
                rolesText = String(data.roles);
            }
        }

        detailData = {
            name: data.book_name,
            cover: replaceCover(data.thumb_url),
            author: data.author,
            description: data.book_abstract_v2,
            detail: `Nguyên Tên: ${data.original_book_name}<br>` +
                    `Mở Hố: ${data.create_time.split('T')[0]}<br>` +
                    `Nhãn Hiệu: ${data.tags}<br>` +
                    `Nhân Vật Chính: ${rolesText}<br>` +
                    `Online: ${data.read_count} Người Đọc<br>` +
                    `Bản Quyền Tin Tức: ${data.copyright_info}`,
            ongoing: data.creation_status === "1",
            genres: genres,
            suggests: [],
            comments: []
        };

        let kind = `${data.category}<br>${data.pure_category_tags}<br>连载${data.creation_status === "1" ? "Đang Ra" : "Hoàn Thành"}<br>${data.score} điểm<br>${new Date(data.last_chapter_update_time * 1000).toLocaleDateString('zh-CN', { year: 'numeric', month: 'short', day: 'numeric' })}`;
        detailData.detail += "<br><br>Thể Loại: " + kind;

        detailData.lastChapter = `${data.last_chapter_title} • ${new Date(data.last_chapter_update_time * 1000).toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' })}`;
    return Response.success(detailData);
}