function execute(input, page) {
    const baseUrl = "http://yuefanqie.jingluo.love";
    let actualUrl;

    if (typeof input === 'function') {
        actualUrl = input();
    } else {
        actualUrl = input;
    }

    actualUrl = actualUrl.replace(/\{\{(.*?)\}\}/g, '');

    if(!page) page = '1';
    let response = fetch(actualUrl + page + "&limit=10&tags=%5B%22无敌%22%5D&creation_status=ALL&word_num=0&sort=0");

    let bookList = [];
    let result = response.json();
    let exploreData = result;
    let books = exploreData[0].content;

    books.forEach(item => {
        bookList.push({
            name: item.book_name,
            link: baseUrl + `/detail?book_id=${item.book_id}`,
            cover: item.thumb_url,
            description: item.abstract
        });
    });

    let next = (parseInt(page) + 1).toString();
    return Response.success(bookList, next);
}