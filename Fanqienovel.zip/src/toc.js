function execute(url) {
    let bookId = null;
    const pageIdMatch = url.match(/https:\/\/fanqienovel\.com\/page\/(\d+)/);
    if (pageIdMatch) {
        bookId = pageIdMatch[1];
    } else {
        const detailIdMatch = url.match(/http:\/\/yuefanqie\.jingluo\.love\/detail\?book_id=(\d+)/);
        if (detailIdMatch) {
            bookId = detailIdMatch[1];
        }
    }

    if (!bookId) {
        return Response.error("Không thể xác định book_id từ URL: " + url);
    }

    let catalogUrl = `http://yuefanqie.jingluo.love/catalog?book_id=${bookId}`;
    let response = fetch(catalogUrl);
    let html = response.text();
    let chapterList = [];
    let jsonResponse = JSON.parse(html);
    let items = jsonResponse.data.item_data_list;

    items.forEach(item => {
        chapterList.push({
            name: item.title,
            url: `http://yuefanqie.jingluo.love/content?item_id=${item.item_id}`
        });
    });

    return Response.success(chapterList);
}