function execute() {
    return Response.success([
        { title: "人妻熟女", input: "http://www.h528.com/post/category/%e4%ba%ba%e5%a6%bb%e7%86%9f%e5%a5%b3", script: "gen.js" },
        { title: "家庭亂倫", input: "http://www.h528.com/post/category/%e5%ae%b6%e5%ba%ad%e4%ba%82%e5%80%ab", script: "gen.js" },
        { title: "強暴虐待", input: "http://www.h528.com/post/category/%e5%bc%b7%e6%9a%b4%e8%99%90%e5%be%85", script: "gen.js" },
        { title: "學生校園", input: "http://www.h528.com/post/category/%e6%a0%a1%e5%9c%92%e5%b8%ab%e7%94%9f", script: "gen.js" },
        { title: "武俠科幻", input: "http://www.h528.com/post/category/%e6%ad%a6%e4%bf%a0%e7%a7%91%e5%b9%bb", script: "gen.js" },
        { title: "動漫改編", input: "http://www.h528.com/post/category/%e5%8b%95%e6%bc%ab%e6%94%b9%e7%b7%a8", script: "gen.js" },
        { title: "名人明星", input: "http://www.h528.com/post/category/%e5%90%8d%e4%ba%ba%e6%98%8e%e6%98%9f", script: "gen.js" },
        { title: "都市生活", input: "http://www.h528.com/post/category/%e9%83%bd%e5%b8%82%e7%94%9f%e6%b4%bb", script: "gen.js" },
        { title: "變身系列", input: "http://www.h528.com/post/category/%e8%ae%8a%e8%ba%ab%e7%b3%bb%e5%88%97", script: "gen.js" },
        { title: "經驗故事", input: "http://www.h528.com/post/category/%e7%b6%93%e9%a9%97%e6%95%85%e4%ba%8b", script: "gen.js" },
        { title: "另類其它", input: "http://www.h528.com/post/category/%e5%8f%a6%e9%a1%9e%e5%85%b6%e5%ae%83", script: "gen.js" },
        { title: "性知識", input: "http://www.h528.com/post/category/%e6%80%a7%e7%9f%a5%e8%ad%98", script: "gen.js" }
    ]);
}
