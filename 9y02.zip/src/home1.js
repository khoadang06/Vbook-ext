load('config.js');
function execute(url,page) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (!page) page = '1';
    const doc = fetch(BASE_URL + url + page).html();
    var next = doc.select("a:contains(下一页)").first().attr("href")
    const el = doc.select(".common-comic-item")
    const data = [];
    for (var i = 0; i < el.size(); i++) {
        var e = el.get(i);
        let img = e.select(".cover img").first().attr("data-original") || e.select(".cover img").first().attr("src");
        data.push({
            name: e.select(".comic__title a").first().text(),
            link: e.select(".comic__title a").first().attr("href"),
            cover: img,
            description: e.select(".cover .comic-feature").first().text(),
            host: BASE_URL
        })
    }
    return Response.success(data,next)
}