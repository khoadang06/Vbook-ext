function execute(url) {
    var doc = fetch(url).html();
    var el = doc.select(".rd-article-wr .rd-article__pic img");   
    var data = [];
    for (var i = 0; i < el.size(); i++) {
        var e = el.get(i);
        data.push(e.attr("data-original"));     
    }
    return Response.success(data);
}