load('config.js')
function execute(url) {
    const doc = fetch(url).html()
    return Response.success({
        name: doc.select(".de-info__box .comic-title").text().replace(/NEW |Ongoing /gi,''),
        cover: doc.select(".de-info__cover img").first().attr("src"),
        author: doc.select(".comic-author .name a").first().text(),
        description: doc.select(".comic-intro .intro").text(),
        detail: doc.select("div.post-status > div:nth-child(1)").html()+ "<br>" + doc.select("div.post-status > div:nth-child(2)").html(),
        category: doc.select(".comic-status .text b").html(),
        host: BASE_URL
    });
}