function execute() {
    return Response.success([
        { title: "Huyền Huyễn", input: "https://doctruyenchufull.org/huyen-huyen", script: "gen.js" },
        { title: "Tiên Hiệp", input: "https://doctruyenchufull.org/tien-hiep", script: "gen.js" },
        { title: "Ngôn Tình", input: "https://doctruyenchufull.org/ngon-tinh", script: "gen.js" },
        { title: "Đô Thị", input: "https://doctruyenchufull.org/do-thi", script: "gen.js" },
        { title: "Xuyên Không", input: "https://doctruyenchufull.org/xuyen-khong", script: "gen.js" },
        { title: "Trọng Sinh", input: "https://doctruyenchufull.org/trong-sinh", script: "gen.js" },
        { title: "Tu Chân", input: "https://doctruyenchufull.org/tu-chan", script: "gen.js" },
        { title: "Kiếm Hiệp", input: "https://doctruyenchufull.org/kiem-hiep", script: "gen.js" },
        { title: "Hệ Thống", input: "https://doctruyenchufull.org/he-thong", script: "gen.js" },
        { title: "Cung Đấu", input: "https://doctruyenchufull.org/cung-dau", script: "gen.js" },
        { title: "Đam Mỹ", input: "https://doctruyenchufull.org/dam-my", script: "gen.js" },
    ]);
}