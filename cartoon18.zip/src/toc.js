load('config.js');
function execute(url) {
    var doc = fetch(url).html();
    var el = doc.select(".container-fluid > div > .mb-2")
    const data = [];
    for (var i = el.size() - 1; i >= 0; i--) {
        var e = el.get(i);
        data.push({
            name: e.text(),
            url: BASE_URL + e.attr("href"),
            host: BASE_URL
        })
    }
    let pr = data.reverse();
    return Response.success(data);
}