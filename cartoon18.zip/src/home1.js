load('config.js');
function execute(url,page) {
    if(!page) page = '1';
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    const doc = fetch(BASE_URL + url + "&page=" + page + "&per-page=24").html();
    const el = doc.select("#videos > div > div")
    const data = [];
    for (var i = 0; i < el.size(); i++) {
        var e = el.get(i);
        let img = e.select("img").first().attr("data-src") || e.select("img").first().attr("src");
        data.push({
            name: e.select(".card-body .lines-2 a").first().text(),
            link: BASE_URL + e.select("a").first().attr("href"),
            cover: img,
            description: e.select(".card-body .lines-1").text(),
            host: BASE_URL
        })
    }
    let next = (parseInt(page) + 1).toString();
    return Response.success(data,next)
}