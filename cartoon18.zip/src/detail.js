load('config.js')
function execute(url) {
    const doc = fetch(url).html()
    return Response.success({
        name: doc.select("h1").text().replace(/NEW |Ongoing /gi,''),
        cover: doc.select(".mb-4 div a img").first().attr("src"),
        author: doc.select(".mb-4 div").last().select(".my-2").first().text(),
        detail: doc.select("div.col-xl-9").select("div.my-2").last().select("span").last().html(),
        category: doc.select("div.col-xl-9").select("div.my-2").last().select("span").last().html(),
        host: BASE_URL
    });
}