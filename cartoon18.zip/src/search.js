load("config.js");
function execute(key, page) {
    if(!page) page = '1';
    let response = fetch(BASE_URL + "/?q=" + key + "?page=" + page);
    if (response.ok) {
        let doc = response.html();
        let books = [];
        doc.select("#videos > div > div").forEach(e => {
            let img = e.select("img").first().attr("data-src") || e.select("img").first().attr("src");
            books.push({
              name: e.select(".card-body .lines-2 a").first().text(),
              link: BASE_URL + e.select("a").first().attr("href"),
              cover: img,
              description: e.select(".card-body .lines-1").text(),
                host: BASE_URL
            })
        });
        let next = (parseInt(page) + 1).toString();
        return Response.success(books,next);
    }

    return null;
}