function execute() {
    return Response.success([
        { title: "玄幻奇幻", input: "/fenlei/1/", script: "cate.js" },
        { title: "武侠修真", input: "/fenlei/2/", script: "cate.js" },
        { title: "都市言情", input: "/fenlei/3/", script: "cate.js" },
        { title: "历史军事", input: "/fenlei/4/", script: "cate.js" },
        { title: "耽美女频", input: "/fenlei/5/", script: "cate.js" },
        { title: "游戏竞技", input: "/fenlei/6/", script: "cate.js" },
        { title: "科幻惊悚", input: "/fenlei/7/", script: "cate.js" },
        { title: "其他类型", input: "/fenlei/8/", script: "cate.js" },
    ]);
}