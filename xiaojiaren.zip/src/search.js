load("config.js");
function execute(key, page) {
    if(!page) page = 1
    let response = fetch(BASE_URL + "/search/?searchkey=" + key, {
        method: "GET",
    });
    if (response.ok) {
        let doc = response.html();
        let books = [];
        doc.select(".partlist-info dl").forEach(e => {
            books.push({
                name: e.select("dt").last().text(),
                link: e.select("a").first().attr("href"),
                cover: e.select(".pic img").attr("src"),
                description: e.select(".info a p").text(),
                host: BASE_URL
            })
        });
        let next = (parseInt(page) + 1).toString();
        return Response.success(books,next);
    }

    return null;
}